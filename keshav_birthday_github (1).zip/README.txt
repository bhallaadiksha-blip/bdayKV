KESHAV BIRTHDAY WEBSITE - GITHUB PAGES

1. Put your remaining 5 photos in photos/ and name them:
   photo2.jpeg, photo3.jpeg, photo4.jpeg, photo5.jpeg, photo6.jpeg

2. Keep the music file in music/ named birthday.mp3

3. Upload the whole folder contents to a GitHub repository.
4. GitHub repository -> Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
5. Open the generated github.io link.

Music starts when the visitor clicks Continue. This is required by most browsers; automatic audio before a user gesture is blocked.
